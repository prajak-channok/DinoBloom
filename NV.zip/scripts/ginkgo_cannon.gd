extends Node2D
class_name GinkgoCannon

const DATA: PlantData = preload("res://data/plants/ginkgo_cannon.tres")
const DESIGN_CELL_HEIGHT: float = 104.0
const ATTACK_ANIMATION := "attack"
const ATTACK_FRAME := 5

@export var bounce_speed: float = 0.7
@export var bounce_scale: float = 0.025
@export var bob_amount: float = 3.0

@onready var visual: Node2D = $Visual
@onready var animated_sprite: AnimatedSprite2D = $Visual/AttackSprite
@onready var interaction_area: Area2D = $InteractionArea
@onready var interaction_shape: CollisionShape2D = $InteractionArea/CollisionShape2D
@onready var attack_sound: AudioStreamPlayer2D = $AudioStreamPlayer2D

var _base_position: Vector2
var _base_scale: Vector2
var _base_rotation: float

var bounce_time: float = 0.0
var _attacking: bool = false
var _combat_enabled: bool = false
var _gameplay: Node = null

var grid_row: int = -1
var grid_column: int = -1

var _hp: float = 0.0
var _attack: float = 0.0
var _attack_timer: float = 0.0
var _cell_size: Vector2 = Vector2.ZERO
var _conversion_timer: float = 0.0
var _current_target: Node2D = null
var _conversion_cooldown: float = 0.0


func _ready() -> void:
	add_to_group("plants")

	_base_position = visual.position
	_base_scale = visual.scale
	_base_rotation = visual.rotation

	_show_idle()


func set_grid_cell(row: int, column: int, cell_size: Vector2) -> void:
	grid_row = row
	grid_column = column
	_cell_size = cell_size

	visual.scale = Vector2.ONE * (cell_size.y / DESIGN_CELL_HEIGHT)
	_base_scale = visual.scale

	interaction_shape.shape = _make_cell_shape(cell_size)


func _make_cell_shape(cell_size: Vector2) -> RectangleShape2D:
	var shape := RectangleShape2D.new()
	shape.size = cell_size
	return shape


func _process(delta: float) -> void:
	if _combat_enabled:
		_combat_process(delta)

	if _attacking:
		return

	bounce_time += delta * bounce_speed * TAU * 0.3

	var wobble: float = sin(bounce_time)

	var squash_x: float = 1.0 + wobble * bounce_scale
	var squash_y: float = 1.0 - wobble * bounce_scale * 0.8

	visual.scale = _base_scale * Vector2(squash_x, squash_y)

	var bob: float = -abs(wobble) * bob_amount

	visual.position = _base_position + Vector2(0.0, bob)


func play_attack() -> void:
	if _attacking:
		return

	_attacking = true

	visual.position = _base_position
	visual.scale = _base_scale
	visual.rotation = _base_rotation

	bounce_time = 0.0

	animated_sprite.play(ATTACK_ANIMATION)
	
	if attack_sound:
			attack_sound.play()


func _on_attack_sprite_frame_changed() -> void:
	if not _attacking:
		return

	if animated_sprite.animation == ATTACK_ANIMATION \
			and animated_sprite.frame == ATTACK_FRAME:
		_spawn_projectile()


func _spawn_projectile() -> void:
	if _current_target == null or not is_instance_valid(_current_target):
		return

	if _gameplay == null:
		return

	var projectile_scene: PackedScene = load(
		"res://scenes/plants/ginkgo_projectile.tscn"
	)

	if projectile_scene == null:
		return

	var projectile: Node2D = projectile_scene.instantiate() as Node2D
	_gameplay.add_child(projectile)
	projectile.global_position = global_position + Vector2(
		_cell_size.x * 0.25,
		-_cell_size.y * 0.08
	)

	# Effect and damage are mutually exclusive per shot: a Conversion shot
	# deals no damage, a damage shot never attempts Conversion.
	var use_conversion: bool = _conversion_timer >= _conversion_cooldown
	if use_conversion:
		_conversion_timer = 0.0

	projectile.setup(
		_current_target,
		_attack,
		grid_row,
		use_conversion
	)

func _on_attack_sprite_animation_finished() -> void:
	if not _attacking:
		return

	_show_idle()

	_current_target = null


func _show_idle() -> void:
	_attacking = false

	animated_sprite.stop()
	animated_sprite.animation = ATTACK_ANIMATION
	animated_sprite.frame = 0

	bounce_time = 0.0

	visual.position = _base_position
	visual.scale = _base_scale
	visual.rotation = _base_rotation


func setup_combat(gameplay: Node, row: int) -> void:
	_gameplay = gameplay
	grid_row = row

	_hp = DATA.base_hp

	var final_stats: Variant = PlantProgression.get_final_stats(DATA.id)

	_attack = final_stats.attack if final_stats != null else DATA.base_attack

	var ability_data: Dictionary = final_stats.ability_data if final_stats != null else DATA.ability_data
	_conversion_cooldown = float(ability_data.get("passive_cooldown", 20.0))

	_attack_timer = DATA.attack_interval
	# Ready to use the Conversion Ability immediately on first placement.
	_conversion_timer = _conversion_cooldown
	_combat_enabled = true


func _combat_process(delta: float) -> void:
	_attack_timer += delta
	_conversion_timer = minf(_conversion_timer + delta, _conversion_cooldown)

	if _attack_timer < DATA.attack_interval:
		return

	var target: Node2D = _find_nearest_enemy()

	if target == null:
		return

	_attack_timer = 0.0
	_current_target = target

	play_attack()


func _find_nearest_enemy() -> Node2D:
	var best: Node2D = null
	var best_distance: float = INF

	for node: Node in get_tree().get_nodes_in_group("enemies"):
		if not is_instance_valid(node) or node is not Node2D:
			continue

		if int(node.get("grid_row")) != grid_row:
			continue

		var enemy := node as Node2D

		if enemy.position.x < position.x:
			continue

		var distance: float = enemy.position.x - position.x

		if distance < best_distance:
			best = enemy
			best_distance = distance

	return best


func get_interaction_rect() -> Rect2:
	return Rect2(
		position - _cell_size * 0.5,
		_cell_size
	)

func take_damage(amount: float) -> void:
	_hp -= amount

	if _hp <= 0.0:
		queue_free()

func get_hp() -> float:
	return _hp
